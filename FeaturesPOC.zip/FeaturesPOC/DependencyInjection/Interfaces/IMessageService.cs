﻿namespace DependencyInjection.Interfaces
{
    public interface IMessageService
    {
        public string Recepient { get; set; }
        public bool IsAttachmentIncluded { get; set; }

        public void SendMessage(string recepient, string messageBody, bool isAttachmentRequired);
    }
}
