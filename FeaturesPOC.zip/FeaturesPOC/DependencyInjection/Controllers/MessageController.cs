﻿using DependencyInjection.Interfaces;
using DependencyInjection.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DependencyInjection.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessageController : ControllerBase
    {
        private readonly IServiceProvider _serviceProvider;
        public MessageController(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }
        // POST api/<MessageController>
        [HttpPost]
        public IActionResult PostMessage(RequestModel request)
        {
            var platform = request.MessagePlatform.ToLower();
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid message Platform");
            }
            var msgService = _serviceProvider.GetRequiredKeyedService<IMessageService>(platform);
            msgService.SendMessage(request.Receipent, platform, request.IsAttachmentIncluded);
            return Ok($"Message was sent successfully via {platform}");
        }

        
    }
}
