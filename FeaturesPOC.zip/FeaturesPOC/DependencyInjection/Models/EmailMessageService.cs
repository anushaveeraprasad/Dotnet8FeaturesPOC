﻿using DependencyInjection.Interfaces;

namespace DependencyInjection.Models
{
    public class EmailMessageService: IMessageService
    {
        public string Recepient { get; set; }
        public bool IsAttachmentIncluded { get; set; }
        public void SendMessage(string recepient, string messageBody, bool isAttachmentRequired)
        {
            Console.WriteLine($"E-mail message with below message body has been sent to {recepient}");
            Console.WriteLine($"{messageBody}");
            if (isAttachmentRequired == true)
            {
                Console.WriteLine("PFA attachment");
            }
            else
            {
                Console.WriteLine("No Attachments");
            }
        }
    }
}
