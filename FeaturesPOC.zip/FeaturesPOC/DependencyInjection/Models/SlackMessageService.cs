﻿using DependencyInjection.Interfaces;

namespace DependencyInjection.Models
{
    public class SlackMessageService: IMessageService
    {
        public string Recepient { get; set; }=string.Empty;
        public bool IsAttachmentIncluded { get; set; }
        public void SendMessage(string recepient, string messageBody, bool isAttachmentRequired)
        {
            Console.WriteLine($"Below SLACK MESSAGE was sent to {Recepient}");
            Console.WriteLine($"{messageBody}");
            if (isAttachmentRequired == true)
            {
                Console.WriteLine("PFA attachment");
            }
            else
            {
                Console.WriteLine("No Attachments");
            }
        }
    }
}
