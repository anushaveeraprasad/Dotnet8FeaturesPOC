﻿using DependencyInjection.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace DependencyInjection.Models
{
    public class RequestModel
    {

        public string Message { get; set; }
        [AllowedValues("slack","email")]
        public string MessagePlatform { get; set; }
        public string Receipent { get; set; }
        public bool IsAttachmentIncluded { get; set; }
    }
}
