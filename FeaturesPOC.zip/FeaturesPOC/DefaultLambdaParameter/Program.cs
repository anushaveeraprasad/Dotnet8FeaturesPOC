﻿using System.Threading.Channels;

var lambdaRole = (string role = "Basic User") => Console.WriteLine($"Tom has {role} role now");
lambdaRole("Premium User");
lambdaRole(); //Default lambda parameter value