﻿using System.Collections;
using Iarray = int[];
List<string> firstList = ["AngularJS", "Angular", "React" ];
List<string> secondList = [ ".Net", "Java", "Go", "Python" ];

List<string> finalList = [.. firstList, .. secondList]; //Spread operator for appending

//Initializations of the collections made easy


Iarray firstArray = [1, 2, 3]; //using alias for int[] (built in type)
int[] secondArray = [..firstArray,11, 12, 13];

finalList.ForEach(element => Console.WriteLine(element));
Array.ForEach(secondArray, element => Console.WriteLine(element));

