﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeFeatures
{
    public class Customer(string name,DateOnly dob)
    {
        public string Name { get; } = name;
        public int Age { get; } = DateTime.Today.Year - dob.Year;
        public void Test()
        {
            Console.WriteLine($"{name}'s DOB is {dob}");
        }
    }
}
