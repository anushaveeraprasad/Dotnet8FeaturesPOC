﻿using TimeFeatures;

var customer1 = new Customer("Anu", new DateOnly(1997,02,03));
customer1.Test();