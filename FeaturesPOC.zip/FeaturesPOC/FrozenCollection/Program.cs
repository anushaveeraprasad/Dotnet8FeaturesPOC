﻿using FrozenCollection;
using System;
using System.Collections.Frozen;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a FrozenDictionary with sample data
            Dictionary<int, string> regularData = new Dictionary<int, string>
            {
                { 1, "Item 1" },
                { 2, "Item 2" },
                { 3, "Item 3" }
            };
            //FrozenDictionary<int,string> data = regularData.ToFrozenDictionary();
            MultiThreadClass mObject = new MultiThreadClass(regularData);
            Console.WriteLine("Calling multing threading simulation with regular Dictionary");
            mObject.MultiThreadingWithRegularDictionary();
            Console.WriteLine("-----------------End---------------------");
            Console.WriteLine("Calling multi threading simulation with Frozen dictionary");
            mObject.MultiThreadingWithFrozenDictionary();



        }

       
    }
}

