﻿using System;
using System.Collections.Frozen;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace FrozenCollection
{
    public class MultiThreadClass
    {
        public Dictionary<int, string> regularDictionary;
        public FrozenDictionary<int, string> frozenDictionary;

        public MultiThreadClass(Dictionary<int,string> dict)
        {
            regularDictionary = dict;
            frozenDictionary=dict.ToFrozenDictionary();
        }
        static void AccessRegularData(Dictionary<int, string> data)
        {
            // Synchronization is required to prevent race conditions
            foreach (KeyValuePair<int, string> item in data)
            {
                Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId}: Key={item.Key}, Value={item.Value}");
                Thread.Sleep(500); // Simulate processing time
            }

        }
        static void AccessData(FrozenDictionary<int, string> data)
        {
            // Multiple threads can safely access the data without synchronization
            foreach (KeyValuePair<int, string> item in data)
            {
                Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId}: Key={item.Key}, Value={item.Value}");
                Thread.Sleep(500); // Simulate processing time
            }
        }

        public void MultiThreadingWithRegularDictionary()
        {
            // Simulate multi-threaded access
            Task task1 = Task.Run(() => regularDictionary[1] = $"Modified by Thread {Thread.CurrentThread.ManagedThreadId}"); // Increment key1 by one
            Task task2 = Task.Run(() => regularDictionary[1] + $"Updated by Thread {Thread.CurrentThread.ManagedThreadId}");
            
            Task[] tasks = new Task[4];
            for (int i = 0; i < tasks.Length; i++)
            {
                
                tasks[i] = Task.Run(() => AccessRegularData(regularDictionary));
            }

            Task.WaitAll(tasks);
        }
        public void MultiThreadingWithFrozenDictionary()
        {
            Task[] tasks = new Task[4];
            for (int i = 0; i < tasks.Length; i++)
            {
                tasks[i] = Task.Run(() => AccessData(frozenDictionary));
            }

            Task.WaitAll(tasks);
        }
    }
}
