﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class User
    {

        [Range(1, 10, MinimumIsExclusive = true)]
        public int ExclusiveMinValue { get; set; } // Valid if greater than 1.
        [Range(1, 10, MaximumIsExclusive = true)]
        public int ExclusiveMaxValue { get; set; } // Valid if less than 10.
    }
}
