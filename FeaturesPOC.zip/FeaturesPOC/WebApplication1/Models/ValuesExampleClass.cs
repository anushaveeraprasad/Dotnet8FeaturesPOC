﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class ValuesExampleClass
    {
        [AllowedValues("PhonePe","GPay","Cash")]
        [DeniedValues("credit-card","debit-card")]
        public string PaymentMode { get; set; }
    }
}
