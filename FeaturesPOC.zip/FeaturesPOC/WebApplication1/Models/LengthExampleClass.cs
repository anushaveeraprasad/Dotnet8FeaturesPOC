﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class LengthExampleClass
    {
        [Length(1,3)]
        public ICollection<string> Names { get; set; }=Array.Empty<string>();
    }
}
