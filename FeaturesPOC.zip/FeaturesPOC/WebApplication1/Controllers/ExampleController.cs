﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models; // we can use alias fro this

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExampleController(IConfiguration configuration) : ControllerBase
    {
        private readonly IConfiguration _configuration = configuration;

        // POST api/<ExampleController>
        [HttpPost("struct")]
        public IActionResult StructDefaults([FromBody] User request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            return Ok(request);
        }

        [HttpPost("length")]
        public IActionResult Length([FromBody] LengthExampleClass request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            return Ok(request);
        }
        [HttpPost("values")]
        public IActionResult Length([FromBody] ValuesExampleClass request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            return Ok(request);
        }

    }
}
